window.Threebox = require('./src/Threebox.js'),
window.THREE = require('./src/three.js')
