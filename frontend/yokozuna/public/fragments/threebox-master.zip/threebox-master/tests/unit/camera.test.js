function cameraTest(instance){


}

    
