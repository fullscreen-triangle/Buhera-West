var config = {
    accessToken: 'mapbox key goes here',
    subscriptionKey: 'azure maps subscription key goes here'
};
