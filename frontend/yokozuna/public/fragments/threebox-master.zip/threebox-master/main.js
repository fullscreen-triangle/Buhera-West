module.exports = exports = {
    Threebox: require('./src/Threebox'),
    THREE: require('./src/three.js')
}